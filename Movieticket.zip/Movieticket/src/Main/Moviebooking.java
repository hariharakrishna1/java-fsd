package Main;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Map.Entry;
import java.io.*;

class Customer
{
	public int seatn[];
	
	public int[] getSeatn() {
		return seatn;
	}
	public void setSeatn(int[] seatn) {
		this.seatn = seatn;
	}
	
	
}
class movie
{
	public Date d;
	public String time;
	public String mname;
	public Date getD() {
		return d;
	}
	public void setD(Date d) 
	{
		this.d = d;
	}
	
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	
}
public class Moviebooking 
{
	FileWriter f;
	public String username,pswd;
	HashMap<Integer, String> seat = new HashMap<>();
	public boolean login() 
	{
		// TODO Auto-generated method stub
			HashMap<String,String> users=new HashMap<>();
			String u="aadmin";
			String p="Aadmin";
			Scanner s=new Scanner(System.in);
			System.out.println("Enter ur first time pass");
			username=s.next();
			pswd=s.next();
			if(username.equals(u)&&pswd.equals(p))
			{
				System.out.println("Enter your new username & pin");
				username=s.next();
				pswd=s.next();
				users.put(u, p);
				System.out.println(users);
				return true;
			}
			else 
			{
				System.out.println("enter correct first time pin");
				return false;
			}
			
	}
	
	public void seats()
	{
		int i;
		for(i=0;i<15;i++)
		{
		seat.put(i,"E");
		}
	}
	public void allot(int a[],int n) 
	{
		int i;
		for(i=0;i<n;i++)
		{
		 if(seat.containsKey(a[i]))
		 {
			if(seat.get(a[i]) == "E")
			{
				seat.put(a[i],"R");
			}
		 } 
		}	
	}
	public void displayseats()
	{
		for(Map.Entry<Integer, String> e : seat.entrySet())
        System.out.println("Seat: " + e.getKey()+ " Availability Empty (E)RESERVED (R): " + e.getValue());
	}
	float cost(int n)
	{
		return n*150;
	}
	
	public static void main(String[] args) throws ParseException, IOException
	{
		// TODO Auto-generated method stub
		Customer c=new Customer();
		movie v=new movie();
		FileWriter f=new FileWriter("status.txt",true);
		FileReader fi=new FileReader("status.txt");
		BufferedReader br = new BufferedReader(fi);
		int x,ch,i;
		String u,p,l,k,o;
		Moviebooking m=new Moviebooking();
		Scanner s=new Scanner(System.in);
		System.out.println("WELCOME TO MOVIEBOOKING SIMULATOR");
		if(m.login())
		{
			System.out.println("Enter usernm and pswd");
			u=s.next();
			p=s.next();
			if(u.equals(m.username) && p.equals(m.pswd))
			{
				System.out.println("Enter movie name,date and showtime");
				l=s.next();
				v.setMname(l);
				k=s.next();  
			    Date date1=new SimpleDateFormat("dd/MM/yyyy").parse(k); 
			    v.setD(date1);
			    o=s.next();
			    v.setTime(o);
			    f.write("movie name:"+l+"\n");
			    f.write("Date:"+k+"\n");
			    f.write("Show timing:"+o+"\n");
				System.out.println("Book seat by entering number of seats to be occupied (per seat 150)");
					x=s.nextInt();
					int[] a = new int [x];
					for(i=0;i<x;i++)
					{
						System.out.println("Enter preferred seat (1-10 first row 140-150 last row)");
						for(i=0;i<x;i++)
						{
						a[i]=s.nextInt();
						f.write("Seat no."+a[i]+" ");
						}					
					}
					f.write("\n");
					c.setSeatn(a);
					m.seats();
					m.allot(c.seatn,x);
					m.displayseats();
					float total=m.cost(x);
					System.out.println("Your total cost="+total);
					f.write("total cost:"+total+"\n");
					
			}
			else {System.out.print("Wrong credentials");}
			
		}
		else {System.out.print("Wrong first time pass n usrname");}
		System.out.println("Your ticket status has been updated");
		
		String line;
		while((line = br.readLine()) != null)
		{
			System.out.println(line);
		}
	f.flush();
	f.close();
	}
}
