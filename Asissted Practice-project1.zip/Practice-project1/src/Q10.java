import java.util.*;
import java.util.regex.*;

public class Q10 
{

	public static void main(String[] args) 
	{
		String email;
		Scanner d = new Scanner(System.in);
		email=d.next();
		String regex = "^(.+)@(.+)$";//^[A-Za-z0-9+_.-]+@(.+)$ or ^(.+)@(.+)$
		Pattern pattern = Pattern.compile(regex);
		  Matcher matcher = pattern.matcher(email);
		  System.out.println(email +" : "+ matcher.matches());
		
		// TODO Auto-generated method stub

	}

}
