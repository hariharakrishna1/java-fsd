import java.util.*;

public class Q9 
{

	public static void main(String ar[])
	{
		int ax[]=null;
		int a[]=null;
		int i,j,n;
		System.out.println("Enter no. of elements");
		Scanner s= new Scanner(System.in);
		n=s.nextInt();
		System.out.println("Enter no. of elements");
		for(i=0;i<n;i++)
		{
			a[i] = s.nextInt();
		}
		System.out.println("Enter element to remove");
		j=s.nextInt();
		int k=0;
		while(a[i]==j)
		{
			ax[k]=j;
			i++;
		}
		a[i]='\0';
		
	}
}
