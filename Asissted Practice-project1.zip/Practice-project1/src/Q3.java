//method overloading
class x
{
	//argument based overloading
	void y(int a,int b)
	{
		int c= a + b;
		System.out.println(c);
	}
	void y(int a,int b,int z)
	{
		int d = a-b+z;
		
		System.out.println(d);
	}
	
	//parametric return type based overloading
	void y(double a,double b)
	{
		double p = a+b;
		System.out.println(p);
	}
}

//method overriding
class u
{
	void msg() {System.out.println("U r in U");}
}

class t extends u
{
  void msg() {System.out.println("U r in T"); }
}

public class Q3 {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		System.out.println("\t Method Overloading");
		x i = new x();
		i.y(1,2);
		i.y(1, 2, 3);
		i.y(9.8,8.2);
	
		System.out.println("\t Method Overriding");
		t obj = new t();
		obj.msg();
	}

}
