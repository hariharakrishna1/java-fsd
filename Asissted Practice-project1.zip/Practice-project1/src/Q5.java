import java.util.*;
public class Q5 
{
		
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		ArrayList <String> list1= new ArrayList<String>();  
		LinkedList<String> list2= new LinkedList<String>();  
		Vector<Integer> l3= new Vector<Integer>();
		Stack<Integer> l4 = new Stack<Integer>();
		
		//arraylist
		list1.add("i");//Adding object in arraylist  
		list1.add("V");  
		list1.add("R");  
		list1.add("A");  
		//Traversing list through Iterator  
		Iterator itr=list1.iterator();  
		while(itr.hasNext())
		{  
		System.out.println(itr.next());
		}
		//Linked list
		list2.add("Ri");  
		list2.add("Vy");  
		list2.add("Ri");  
		list2.add("Ay");  
		itr=list2.iterator();  
		while(itr.hasNext())
		{  
		System.out.println(itr.next());
		}
		
		//Vector
		
		l3.add(2);
		l3.add(6);
		l3.add(4);
		l3.add(3);
		Iterator<Integer> ltr=l3.iterator();  
		while(itr.hasNext())
		{  
		System.out.println(ltr.next());
		}
	
		//Stack
		
		l4.add(1);
		l4.add(3);
		l4.add(5);
		l4.add(7);
		ltr=l4.iterator();  
		while(ltr.hasNext())
		{  
		System.out.println(ltr.next());
		}
	}

}
