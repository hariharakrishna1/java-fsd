

class Outer
{
    class Inner
   {
        void innerMethod()
       {
        	 System.out.println("Called the Inner class method");
       }
     
     }
}   
public class Q7 
{

	public static void main(String[] args) 
	{
		Outer.Inner InnerObj=new Outer().new Inner();
        InnerObj.innerMethod();
		// TODO Auto-generated method stub

	}

}
