class one //default access
{
	void msg() 
	{
		System .out.println("Hai its 1");
	}
}

class two //Private access
{
	private int x = 2;
	
	void msg()
	{
		System.out.println("Hai its"+x);
	}
}

//protected starts here 
class three
{
	int x=3;
	protected void display() 
	{
		System.out.println(x);
	}
}
class threechild extends three
{
	void add()
	{
		System.out.println(x+5);
	}
}

//protected ends here
class pub
{
	public int x=4;
}
public class Q2 
{

	public static void main(String[] args) 
	{
		one o = new one();
		o.msg();
		two t2= new two();
		t2.msg();
		threechild t = new threechild();
		t.display();// TODO Auto-generated method stub
		t.add();
		pub p=new pub();
		p.x+=2;
		System.out.println(p.x);
	}
}
