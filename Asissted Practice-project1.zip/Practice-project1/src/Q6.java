import java.util.*;
public class Q6 {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		 Map<Integer, String> m1 = new HashMap<>();
	     Map<Integer, String> m2 = new HashMap<Integer, String>();
	        m1.put(1, "projey");
	        m1.put(2, "to");
	        m1.put(3, "proj");
	        m2.put(new Integer(1), "Hai");
	        m2.put(new Integer(2), "2");
	        m2.put(new Integer(3), "Hello");
	        System.out.println(m1);
	        System.out.println(m2);        
	        m1.remove(new Integer(1));
	        System.out.println(m1);
	}

}
