class s
{
 s()
 {
	 System.out.println("NO ARG Constructor");
 }
 s(int x)
 {
	 System.out.println("Parametrized constructor" + x);
 }
 
}
public class Q4 
{
private int a=5;
	public static void main(String[] args) 
	{
		Q4 n= new Q4(); //default constructor
		System.out.println(n.a);
		s obj= new s();
		s obj1=new s(4);
		// TODO Auto-generated method stub

	}

}
