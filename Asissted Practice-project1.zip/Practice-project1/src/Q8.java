
public class Q8 {

	public static void main(String[] args) 
	{
		String s[]= {"Hello","How","are","you"};
		StringBuilder sb = new StringBuilder(s[1]);
		sb.append(" "+s[0]);
		sb.append(" "+s[1]);
		sb.append(" "+s[2]);
		sb.append(" "+s[3]);
		System.out.println(sb.toString());
		
		String a ="hello";
		StringBuffer ss= new StringBuffer(a);
		ss.append(" "+s[0]);
		ss.append(" "+s[1]);
		ss.append(" "+s[2]);
		ss.append(" "+s[3]);
		System.out.println(ss);
		
		// TODO Auto-generated method stub

	}

}
