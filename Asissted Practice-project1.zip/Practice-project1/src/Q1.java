
public class Q1 {

	public static void main(String[] args) 
	{
	byte x =10;
	short i = x;// TODO Auto-generated method stub
	int j = i;
	long l = j;
	float a = l;
	double n = a;
	System.out.println(x);
	System.out.println(i);
	System.out.println(j);
	System.out.println(l);
	System.out.println(a);
	System.out.println(n);
	
	}

}
