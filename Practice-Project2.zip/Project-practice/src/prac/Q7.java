package prac;
import java.io.*;
import java.util.*;
public class Q7
{
	public static void main(String[] args) throws IOException
	{
		String st;
				Scanner s=new Scanner(System.in);
				/*String st,t= "C:\\Users\\Harihara Krishna\\eclipse-workspace\\Project-practice\\src";
				File fh = new File(t);
				boolean b = fh.createNewFile();*/
				FileOutputStream f=new FileOutputStream("fd",true);
				FileInputStream fi=new FileInputStream("fd");
				/*FileWriter f = new FileWriter("fd",true);
				FileReader x = new FileReader("fd");*/
				int i,j,ch;
				
				if(f!=null)
				{
					System.out.println("File created");
				}
				do 
				{
					System.out.println("-----MENU-----");
					System.out.println("1.Write in FILE");
					System.out.println("2.DISPLAY CONTENTS");
					System.out.println("3.DELETE FILE");
					System.out.println("4.EXIT");
					System.out.println("ENTER CHOICE");
					i=s.nextInt();
					switch(i)
					{
						case 1:
							System.out.println("Enter contents to add in file");
							
							st=s.next();
							byte b[]=st.getBytes();
							f.write(b);
							break;
						case 2:
							
							if(fi!=null)
							{
								System.out.print("file found");
								break;
							}
							System.out.println("Contents are: \n");
							j=0;
							//-1 is EOF
							while((j=fi.read())!=-1)
							{
								System.out.print((char)j);
							}
							break;
					}
					System.out.println("Continue y/n");
					ch=s.nextInt();			
				}
				while(ch==1);	
			}
	}

