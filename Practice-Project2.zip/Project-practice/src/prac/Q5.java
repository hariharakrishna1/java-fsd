package prac;

import java.util.Scanner;

class r extends Exception
{
	public r(String s)
	{
		super(s);
	}
}
class agent
{
void age(int x) throws erro
{
if(x>10)
{
	System.out.println("ok");
}
else throw new erro("should cross 10yrs");
}
}
class trycat
{
	void f() 
	{
		Scanner s=new Scanner(System.in);
		int i=s.nextInt();
		try
		{
			int x= i/0;
		}
		catch(Exception e)
		{	
			System.out.println("divide by zero exception");
		}
		finally {System.out.println("ENTER 0");}
	}
	void f1()
	{
		int i=10;
		try
		{
			if(i<9)
			{
				System.out.println("     k");
			}
	
		}
		finally
		{
			System.out.println("Finally executes no matter what happens");	
		}
	}
}
public class Q5 
{

	public static void main(String[] args) throws erro 
	{
		trycat t=new trycat();
		t.f();
		System.out.print("TRY FINALLY\n");
		t.f1();// TODO Auto-generated method stub
		System.out.println("UDE\n");
		agent a=new agent();
		a.age(7);
	}

}
