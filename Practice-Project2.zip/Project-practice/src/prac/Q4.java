package prac;

import java.util.Scanner;


class trycatch
{
	void f() 
	{
		Scanner s=new Scanner(System.in);
		int i=s.nextInt();
		try
		{
			int x= i/0;
		}
		catch(Exception e)
		{	
			System.out.println("divide by zero exception");
		}
		finally {System.out.println("ENTER 0");}
	}
	void f1()
	{
		int i=10;
		try
		{
			if(i<9)
			{
				System.out.println("     k");
			}
	
		}
		finally
		{
			System.out.println("Finally executes no matter what happens");	
		}
	}
}
public class Q4 
{

	public static void main(String[] args)
	{
		trycatch t=new trycatch();
		t.f();
		System.out.print("TRY FINALLY\n");
		t.f1();// TODO Auto-generated method stub
	}

}
