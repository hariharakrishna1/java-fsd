package prac;

import java.util.Scanner;

class InvalidAgeException extends Exception {

	 InvalidAgeException(String str) 
	 {
		super(str);
	}

}

class AgeValidation {
	
	 void validAge(int age) throws InvalidAgeException {
		if(age>=18) {
			System.out.println("right to vote");
		}
		else {
			throw new InvalidAgeException("the age is not matching with the right of vote");
		}
	}

}

public class Q6 
{
public static void main(String[] args) throws InvalidAgeException
{
	AgeValidation valid=new AgeValidation();
	Scanner s=new Scanner(System.in);
	int i=s.nextInt();
	valid.validAge(i);
}
}
