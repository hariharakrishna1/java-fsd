import java.util.Scanner;

class oper
{
 void add(int a,int b)
 {
	 int c= a+b;
	 System.out.println(c);
 }
 void sub(int a,int b)
 {
	 int c= a-b;
	 System.out.println(c); 
 }
 void mul(int a, int b)
 {
	 int c=a*b;
	 System.out.println(c);
 }
 void div(int a ,int b)
 {
	 int c=a/b;
	 System.out.println(c);
 }
}
public class calc {

	public static void main(String[] args) 
	{	
		oper e = new oper();
		int a,b,n;
		Scanner s= new Scanner(System.in);
		System.out.println("Enter 2 numbers");
		a=s.nextInt();
		b=s.nextInt();
		System.out.println("Enter choice	1.add 2.subt 3.mul 4.div");
		n=s.nextInt();
		if(n == 1)
		{
			e.add(a, b);
		}
		else if(n==2)
		{
			e.sub(a, b);
		}
		else if(n==3)
		{
			e.mul(a, b);
		}
		else if(n==4)
		{
			e.div(a, b);
		}
		else;
		// TODO Auto-generated method stub
	}

}
